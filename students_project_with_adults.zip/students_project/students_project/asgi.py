from django.core.asgi import get_asgi_application
application = get_asgi_application()
