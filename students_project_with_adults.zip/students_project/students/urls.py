from django.urls import path
from .views import student_list, student_adults

urlpatterns = [
    path('', student_list),
    path('adults/', student_adults),
]
